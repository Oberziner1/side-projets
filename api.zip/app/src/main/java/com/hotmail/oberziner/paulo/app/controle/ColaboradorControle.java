package com.hotmail.oberziner.paulo.app.controle;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.hotmail.oberziner.paulo.app.modelo.ColaboradorModelo;
import com.hotmail.oberziner.paulo.app.modelo.RespostaModelo;
import com.hotmail.oberziner.paulo.app.repositorio.ColaboradorRepositorio;

@CrossOrigin(origins="https://localhost:4200")
@RestController
@RequestMapping("/api")
public class ColaboradorControle {

	@Autowired
	private ColaboradorRepositorio colaboradorRepositorio;
	
	@RequestMapping(value="/colaborador", method = RequestMethod.GET)
	public @ResponseBody List<ColaboradorModelo> consultar(){
		return this.colaboradorRepositorio.findAll();
		
	};
	
	@RequestMapping(value="/colaborador/{codigo}", method = RequestMethod.GET)
	public @ResponseBody ColaboradorModelo buscar(@PathVariable("codigo") Integer codigo){
		return  this.colaboradorRepositorio.findByCodigo(codigo);
		
	};
	
	@RequestMapping(value="/colaborador", method = RequestMethod.POST)
	public @ResponseBody RespostaModelo salvar(@RequestBody ColaboradorModelo colaborador){
		try {
			this.colaboradorRepositorio.save(colaborador);
			return new RespostaModelo ("Registro salvo com sucesso");
		} catch (Exception e){
			return new RespostaModelo (e.getMessage());
		}
	
	};
	@RequestMapping(value="/colaborador", method = RequestMethod.PUT)
	public @ResponseBody RespostaModelo atualizar(@RequestBody ColaboradorModelo colaborador){
		try {
			this.colaboradorRepositorio.save(colaborador);
			return new RespostaModelo ("Registro atualizado com sucesso");
		} catch (Exception e){
			return new RespostaModelo (e.getMessage());
		}
	
	};
	
	@RequestMapping(value="/colaborador/{codigo}", method = RequestMethod.DELETE)
	public @ResponseBody RespostaModelo excluir(@PathVariable("codigo") Integer codigo){
		ColaboradorModelo colaboradorModelo = colaboradorRepositorio.findByCodigo(codigo);
		
		try {
			this.colaboradorRepositorio.delete(colaboradorModelo);
			return new RespostaModelo ("Registro excluido com sucesso");
		} catch (Exception e){
			return new RespostaModelo (e.getMessage());
		}
		
	};
	
	
}