package com.hotmail.oberziner.paulo.app.repositorio;

import java.util.List;

import org.springframework.data.repository.Repository;

import com.hotmail.oberziner.paulo.app.modelo.ColaboradorModelo;

public interface ColaboradorRepositorio extends Repository<ColaboradorModelo,Integer>{
	
	void save (ColaboradorModelo aluno);
	List<ColaboradorModelo> findAll();
	ColaboradorModelo findByCodigo(Integer codigo);
	void delete(ColaboradorModelo colaborador);
}
